const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const { sendToTelegram, sendToSecondTelegram } = require('./utils/telegram.cjs');
require('dotenv').config();

// console.log("Chave Stripe carregada:", process.env.STRIPE_SECRET_KEY);

const supabase = createClient(
  process.env.YOUR_SUPABASE_URL,
  process.env.YOUR_SUPABASE_SERVICE_ROLE_KEY
);

const app = express();
app.use('/stripe', require('./stripe/webhook.cjs'));
app.use(cors());

app.use(express.json());
app.use('/api', require('./stripe/create-checkout-session.cjs'));
app.use('/api', require('./stripe/cancel-subscription.cjs'));


// Webhook do TradingView
app.post('/webhook-sinal', async (req, res) => {
  const { msg, signal, price, symbol, pass } = req.body;

  if (pass !== 'Coinvision1234#') {
    return res.status(403).json({ error: 'Unauthorized' });
  }

  const now = new Date().toISOString();

  // ✅ Encaminhar sinal para segundo webhook
  try {
    const forwardUrl = 'https://cripto-vision-server-dev.onrender.com/api/signals/post-signals';
    await axios.post(forwardUrl, req.body, {
      headers: { 'X-Webhook-Source': 'cryptoapp' }
    });
    console.log('✅ Sinal encaminhado com sucesso');
  } catch (err) {
    console.error('❌ Erro ao encaminhar para o segundo webhook:', err.message);
  }

  // 📤 Sinal de fechamento
  if (signal === 'CLOSE') {
    const { data, error: fetchError } = await supabase
      .from('sinais_trade')
      .select('*')
      .eq('symbol', symbol)
      .is('signal_exit', null)
      .order('created_at', { ascending: false })
      .limit(1);

    if (fetchError || !data || data.length === 0) {
      return res.status(404).json({ error: 'Sinal aberto não encontrado' });
    }

    const sinal = data[0];
    const resultado = sinal.signal_entry === 'SELL' ? ((sinal.entry_price - price) / sinal.entry_price) * 100 : ((price - sinal.entry_price) / sinal.entry_price) * 100;

    const { error: updateError } = await supabase
      .from('sinais_trade')
      .update({
        signal_exit: 'CLOSE',
        exit_price: price,
        resultado,
        updated_at: now
      })
      .eq('id', sinal.id);

    if (updateError) {
      console.error(updateError);
      return res.status(500).json({ error: 'Erro ao fechar sinal' });
    }

    // Enviar para o Telegram
    await sendToTelegram({
      symbol,
      signal_exit: 'CLOSE',
      exit_price: price
    });
    // await sendToSecondTelegram({ symbol });

    return res.status(200).json({ success: true, closed: true });
  }

  // 📤 Sinal de BREAKEVEN
  if (signal === 'BREAKEVEN') {
    const { data, error: fetchError } = await supabase
      .from('sinais_trade')
      .select('*')
      .eq('symbol', symbol)
      .is('signal_exit', null)
      .order('created_at', { ascending: false })
      .limit(1);

    if (fetchError || !data || data.length === 0) {
      return res.status(404).json({ error: 'Sinal aberto não encontrado' });
    }

    const sinal = data[0];

    const { error: updateError } = await supabase
      .from('sinais_trade')
      .update({
        breakeven: 'BREAKEVEN',
        updated_at: now
      })
      .eq('id', sinal.id);

    if (updateError) {
      console.error(updateError);
      return res.status(500).json({ error: 'Erro ao atualizar breakeven' });
    }

    await sendToTelegram({
      symbol,
      breakeven: 'BREAKEVEN'
    });
    // await sendToSecondTelegram({ symbol });

    return res.status(200).json({ success: true, breakeven: true });
  }
  if (!signal || typeof signal !== 'string') {
  return res.status(400).json({ error: 'Sinal ausente ou inválido' });
  }

  // 📤 Novo sinal padrão (BUY/SELL)
  const match = signal.match(/(BUY|SELL), ALVO:(.*),STOPLOSS:(.*)/i);
  if (!match) {
    return res.status(400).json({ error: 'Invalid signal format' });
  }

  const [, entry, alvo, stop] = match;

  const newSignal = {
    msg,
    symbol,
    signal_entry: entry.toUpperCase(),
    take_profit: parseFloat(alvo),
    stop_loss: parseFloat(stop),
    entry_price: parseFloat(price),
    created_at: now,
    updated_at: now
  };

  const { error } = await supabase.from('sinais_trade').insert([newSignal]);

  if (error) {
    console.error(error);
    return res.status(500).json({ error: 'Erro ao salvar sinal' });
  }

  await sendToTelegram(newSignal);
  // await sendToSecondTelegram(newSignal);

  return res.status(200).json({ success: true, created: true });
});

// Inicializa servidor
const PORT = process.env.PORT || 10000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
});